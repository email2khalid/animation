function f=Animate(str,chr) %string that rotates along central character
if nargin<2
    chr='🌺';%🕐🕑🕒🕓🕔🕕🕖🕗🕘 %char(9752)%flower=9752
   if nargin<1
       str='Happy Birthday!';
   end
end
fig = figure('MenuBar','none','Color', [0 .4 .3],'Units','Normalized','Position',[.1 .1 .8 .8]);  % Shamrock green
ax = axes(fig,'Units','Normalized','Position',[0 0 1 1]);
axis(ax,'off')
axis(ax,'equal')
hold(ax,'on')
xlim(ax,[-1,1]); ylim(ax,[-1,1])
text(ax, 0, 0, chr, 'VerticalAlignment','middle','HorizontalAlignment','center','FontSize', 400)
str = num2cell(str);
th = linspace(-pi/2,pi/2,numel(str)); 
txtHandle = text(ax,sin(th)*.8, cos(th)*.8, str, 'VerticalAlignment','middle','HorizontalAlignment','center','FontSize', 45);
set(txtHandle,{'rotation'}, num2cell(rad2deg(-th')))
thr = 0.017;
rotateCCW = @(xyz)([cos(thr) -sin(thr) 0; sin(thr), cos(thr), 0; 0 0 1]*xyz.').';
clr=[1 0 .1]; clrf=1-[clr];
t1=double(tic);fs=450;
while all(isvalid(txtHandle))
    text(ax, 0, 0, chr, 'VerticalAlignment','middle','HorizontalAlignment','center','FontSize', fs,'Color',clrf)
    newposition = rotateCCW(vertcat(txtHandle.Position)); 
    set(txtHandle,'Color',clr,{'position'}, mat2cell(newposition,ones(numel(txtHandle),1),3), ...
  {'rotation'}, num2cell([txtHandle.Rotation].'+thr*180/pi))
    drawnow()
    t2=double(tic);
    if (t2-t1)/1e7>.25
        clr=rand(1,3)/2;t1=t2;
        if fs<350, fs=fs*1.2; else, fs=50;end
    else
      if all(clr)<.9,clr-clr*1.2;end
    end
    clrf=1-clr;
 end